'''
PROGRAM: main_Salvo_ANN.py

@Author:
    G. D'Alessio [1,2]
    [1]: Université Libre de Bruxelles, Aero-Thermo-Mechanics Laboratory, Bruxelles, Belgium
    [2]: CRECK Modeling Lab, Department of Chemistry, Materials and Chemical Engineering, Politecnico di Milano

@Contacts:
    giuseppe.dalessio@ulb.ac.be

@Additional notes:
    This code is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
    Please report any bug to: giuseppe.dalessio@ulb.ac.be

'''

import ANN
from utilities import *

# Settings per caricare le matrici:
#1) Percorso (deve essere uguale per input ed output)
#2) Nome dell'input
#3) Nome dell'output

# Le matrici di training devono essere salvate in formato .csv, c'é un comando
# Matlab apposito --> csvwrite('name_matrix.csv', name_matrix);

file_options = {
    "path_to_file"              : "/Users/giuseppedalessio/Dropbox/GitHub/data",

    "input_file_name"           : "CF_pasr_Z.csv",
    "output_file_name"          : "idx_CFP.csv"
}

# Settings per il preprocessing dei dati. Io centro/scalo sempre con "mean" e
# "auto" perché cosí ho tutti i dati con media = 0 e deviazione standard 1.
# Per avere la matrice con i valori compresi tra 0 ed 1 devi selezionare
# centering "MIN" e scaling "RANGE".

settings = {
    "centering_method"          : "MEAN",
    "scaling_method"            : "AUTO",
}

# Hyperparameters per la rete. Per mettere la LeakyRelu (come sta nel loro paper)
# devi mettere "leaky_relu" nel setting dell'attivazione

training_options = {
    "number_of_neurons"         : [20, 40, 60],
    "batch_size"                : 32,
    "activation_hidden"         : "relu",
    "activation_output"         : "softmax",
    "number_of_epochs"          : 200,
    "batchNormalization"        : True,
}

# Sono delle opzioni per evitare l'overfitting. Il primo settings é la percentuale
# di neuroni da mettere in dropout, il secondo é il numero di iterazioni che il
# modello deve aspettare per l'opzione Early Stopping. In pratica se metti questo
# setting = 'n', se la tua rete fa 'n' iterazioni senza migliorare le performance
# si stoppa il training prima della fine delle epochs, cosí non overfitta. Di solito
# dipende dal problema, ma io preferisco EarlyStop al Dropout, e metto patience tra 5
# e 15, a seconda di come va.

overfitting_options = {
    "dropout_percentage"        : 0,
    "patience_EarlyStop"        : 5
}


X = readCSV(file_options["path_to_file"], file_options["input_file_name"])
Y = readCSV(file_options["path_to_file"], file_options["output_file_name"])


X_tilde = center_scale(X, center(X, method=settings["centering_method"]), scale(X, method=settings["scaling_method"]))

### REGRESSION ###                                                          --> RUNNING, OK -- TO TEST

model = ANN.regressor(X_tilde,Y)

model.getNeurons = training_options["number_of_neurons"]
model.activation_function = training_options["activation_hidden"]
model.activationOutput = training_options["activation_output"]
model.n_epochs = training_options["number_of_epochs"]
model.batch_size = training_options["batch_size"]

model.dropout = overfitting_options["dropout_percentage"]
model.patience = overfitting_options["patience_EarlyStop"]

model.batchNormalization = training_options["batchNormalization"]

predicted_X = model.fit_network()
predictedTest, trueTest = model.predict()
